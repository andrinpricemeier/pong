Remove-Item node_modules -Recurse -ErrorAction Ignore
Remove-Item .serverless -Recurse -ErrorAction Ignore